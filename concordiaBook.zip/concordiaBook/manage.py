import os


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ConcordiaBook.settings')
