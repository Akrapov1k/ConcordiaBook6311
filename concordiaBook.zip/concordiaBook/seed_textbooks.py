from pathlib import Path
import os, sys, django

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "ConcordiaBook.settings")

django.setup()

from django.db import connection
from django.core.management import call_command
from textbooks.models import Textbook


def table_exists(table_name: str) -> bool:
    with connection.cursor() as cursor:
        tables = connection.introspection.table_names()
    return table_name in tables


def ensure_migrated():
    # textbooks_textbook table exists?
    if not table_exists('textbooks_textbook'):
        print("[seed] 未检测到表 textbooks_textbook，开始生成并应用迁移...")
        # make migrations
        call_command('makemigrations', 'textbooks', verbosity=1, interactive=False)
        # apply the migration
        call_command('migrate', 'textbooks', verbosity=1, interactive=False)
        # check again
        if not table_exists('textbooks_textbook'):
            raise SystemExit("[seed] 迁移后仍未检测到表 textbooks_textbook，请检查 models.py 和 INSTALLED_APPS。")
        print("[seed] 迁移完成。")


def seed():
    # clear existing data
    Textbook.objects.all().delete()

    sample_books = [
        # COEN6311（3）
        Textbook(title="Introduction to Algorithms", author="Cormen et al.", edition="3rd", condition="used", course_code="COEN6311", availability=True),
        Textbook(title="Deep Learning", author="Ian Goodfellow", edition="1st", condition="new", course_code="COEN6311", availability=True),
        Textbook(title="Data Mining Concepts", author="Han & Kamber", edition="2nd", condition="used", course_code="COEN6311", availability=False),  # setting False

        # COEN6321（3）
        Textbook(title="Software Engineering", author="Ian Sommerville", edition="10th", condition="used", course_code="COEN6321", availability=True),
        Textbook(title="Clean Code", author="Robert C. Martin", edition="1st", condition="new", course_code="COEN6321", availability=True),
        Textbook(title="Computer Networks", author="Tanenbaum", edition="5th", condition="used", course_code="COEN6321", availability=True),

        # ELEC6041（3）
        Textbook(title="Digital Signal Processing", author="Oppenheim", edition="3rd", condition="used", course_code="ELEC6041", availability=True),
        Textbook(title="Analog Integrated Circuits", author="Sedra/Smith", edition="2nd", condition="new", course_code="ELEC6041", availability=True),
        Textbook(title="Microwave Engineering", author="Pozar", edition="4th", condition="used", course_code="ELEC6041", availability=True),

        # ELEC6061（3）
        Textbook(title="Wireless Communications", author="Goldsmith", edition="1st", condition="used", course_code="ELEC6061", availability=True),
        Textbook(title="Control Systems Engineering", author="Nise", edition="7th", condition="new", course_code="ELEC6061", availability=True),
        Textbook(title="Embedded Systems", author="Barr & Massa", edition="2nd", condition="used", course_code="ELEC6061", availability=False),  # setting False

        # ENGR6421（3）
        Textbook(title="Project Management", author="Gray & Larson", edition="4th", condition="used", course_code="ENGR6421", availability=True),
        Textbook(title="Innovation Management", author="Schilling", edition="3rd", condition="new", course_code="ENGR6421", availability=True),
        Textbook(title="Engineering Economics", author="Blank & Tarquin", edition="7th", condition="used", course_code="ENGR6421", availability=True),

        # ENGR6131（3）
        Textbook(title="Thermodynamics", author="Moran", edition="8th", condition="used", course_code="ENGR6131", availability=True),
        Textbook(title="Fluid Mechanics", author="White", edition="9th", condition="used", course_code="ENGR6131", availability=True),
        Textbook(title="Mechanics of Materials", author="Beer & Johnston", edition="7th", condition="new", course_code="ENGR6131", availability=True),
    ]

    Textbook.objects.bulk_create(sample_books, ignore_conflicts=True)
    total = Textbook.objects.count()
    coen6311_true = Textbook.objects.filter(course_code="COEN6311", availability=True).count()
    print(f"[seed] import confirmed：total={total}；COEN6311 available={coen6311_true}")


if __name__ == "__main__":
    ensure_migrated()
    seed()
