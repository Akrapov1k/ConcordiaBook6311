
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Textbook',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('title', models.CharField(max_length=100)),
                ('author', models.CharField(max_length=100)),
                ('edition', models.CharField(max_length=20)),
                ('condition', models.CharField(max_length=20)),
                ('course_code', models.CharField(max_length=20)),
                ('availability', models.BooleanField(default=True)),
            ],
        ),
    ]
