# textbooks/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('<str:course_code>/', views.available_textbooks, name='available_textbooks'),
]
